﻿// Pr1.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include "pch.h"
#include <string>
#include <iostream>

using namespace std;

int main()
{
	string name;
    cout << "What is your name: ";
	cin >> name;
	cout << "Hello " << name << endl;
}

